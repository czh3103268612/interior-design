/**
 * Created by Administrator on 2019/8/5.
 */
//设计师轮播
$(function(){
    $(".carousel").carousel();
})
//页面滚动
$(function(){
    var h=$(window).height();
    $(".index-wrap").height(h);
    var h0=$(".index-about").innerHeight();
    var h1=$(".index-designs").innerHeight();
    var h2=$(".index-serv").innerHeight();
    var h3=$(".index-team").innerHeight();
    var h4=$(".index-port").innerHeight();
    var h5=$(".index-test").innerHeight();
    $("#fun2").click(function(){
        $(".index-wrap").animate({scrollTop:663+"px"},600)
    })
    $("#up").click(function(){
        $(".index-wrap").animate({scrollTop:0+"px"},600)
    })
    $("#fun3").click(function(){
        $(".index-wrap").animate({scrollTop:(h1+h0+663)+"px"},600)
    })
    $("#fun4").click(function(){
        $(".index-wrap").animate({scrollTop:(h1+h0+h2+663)+"px"},600)
    })
    $("#fun5").click(function(){
        $(".index-wrap").animate({scrollTop:(h1+h0+h2+h3+663)+"px"},600)
    })
    $("#fun6").click(function(){
        $(".index-wrap").animate({scrollTop:(h1+h0+h2+h3+h4+663)+"px"},600)
    })
    $("#fun7").click(function(){
        $(".index-wrap").animate({scrollTop:(h1+h0+h2+h3+h4+h5+663)+"px"},600)
    })
    //设计中的边框及文字
    $(".designs").mouseenter(function(){
        $(this).find(".designs-img").find(".designs-move").find(".show-p").stop(true,true).fadeIn(500);
        $(this).find(".designs-img").find("img").animate({left:"-70px"},500)
    })
    $(".designs").mouseleave(function(){
        $(this).find(".designs-img").find(".designs-move").find(".show-p").stop(true,true).fadeOut(500);
        $(this).find(".designs-img").find("img").animate({left:"-50px"},500)
    })
    //设计师介绍部分
    $(".team0").mouseenter(function(){
        $(this).find(".team-up").css({display:"block"}).stop(true,true).animate({height:"30%"},500)
    })
    $(".team0").mouseleave(function(){
        $(this).find(".team-up").css({display:"none"}).stop(true,true).animate({height:"0%"},500)
    })
    //设计师QQ微信微博部分
    $(".team0").mouseenter(function(){
        $(this).find(".team-three").stop(true,true).fadeIn(1000)
    })
    $(".team0").mouseleave(function(){
        $(this).find(".team-three").stop(true,true).fadeOut(500)
    })
    //设计欣赏部分
    $(".port div").mouseenter(function(){
        $(this).find("span").fadeIn(function(){
            $(this).animate({bottom:"45%"},500);
        })
    })
    $(".port div").mouseleave(function(){
        $(this).find("span").fadeOut(function(){
            $(this).animate({bottom:"25%"},500);
        })
    })
    //表单检验部分
    $(".btn").click(function(){
        var u=$(".user").val()
        if(u==""){
            $(".imp").css({display:"block"})
        }else{
            $(".imp").css({display:"none"})
        }
    })
    //上面的文字轮播
    setInterval("fun()",3000)
})
function fun(){
    var v1=$(".nav-word-in .text");
    var v2;
    if(v1.next().length==0){
        v2=$(".nav-word-in div:first");
    }else{
        v2=v1.next();
    }
    var i=v2.index();
    v1.animate({opacity:0},1000,function(){
        v1.removeClass("text");
    })
    v2.animate({opacity:1},1000,function(){
        v2.addClass("text");
    })
}